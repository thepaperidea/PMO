<?php

require 'vendor/autoload.php';
require 'includes/config.php';
require 'includes/config-prod.php';
require 'includes/kernel.php';
require 'includes/controller.php';
require 'includes/connect.php';
require 'includes/route.php';
require 'includes/disconnect.php';
